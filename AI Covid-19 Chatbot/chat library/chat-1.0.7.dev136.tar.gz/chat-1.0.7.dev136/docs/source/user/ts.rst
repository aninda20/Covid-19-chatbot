.. _ts:

=====================
技术支持
=====================

Github
=====================

您可以在下列网址提问或加入 Chat 开发讨论:

Chat Google group
Chat Slack channel, 点击这里获得邀请.
您也可以在 Github issues 里提问或请求新特性。在提问之前请确保您阅读过我们的文档

FAQ
=====================

请见 `常见问题解答 <http://chat-cn.readthedocs.io/zh_CN/latest/user/more.html>`_ .

您的贡献
=====================

贡献方式有很多种，比如提供建议、应用、实现新的 Chat 模块、回答 `GitHub`_ Issues 以及帮助完善文档等等。
每一点贡献都会署名，欢迎在 `GitHub`_ 上 push。
