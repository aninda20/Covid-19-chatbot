.. _thanks:

======================
致谢
======================

本项目由以下贡献者贡献:

代码贡献
==================

* `Decalogue <https://github.com/decalogue/chat>`_

文档贡献
==================

* `Decalogue <https://github.com/decalogue/chat>`_

建议贡献
==================

* `zheyang0715 <https://github.com/zheyang0715>`_
具体内容：chat.semantic.synonym_cut 句尾标点符号过滤

* `zhengxijiang <https://github.com/zhengxijiang>`_
具体内容：chat.server 场景并发中 robot 实例化

* 各位热心朋友的建议以及在 Issues 里的提问
