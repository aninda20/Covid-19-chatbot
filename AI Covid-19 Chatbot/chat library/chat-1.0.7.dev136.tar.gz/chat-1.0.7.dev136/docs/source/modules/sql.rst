API - 语义数据库管理 SQL 版本
========================

.. image:: my_figs/sql.png
  :scale: 50 %

.. automodule:: chat.sql

.. autosummary::

   Database
   
语义数据库管理
------------------------
.. autofunction:: Database
