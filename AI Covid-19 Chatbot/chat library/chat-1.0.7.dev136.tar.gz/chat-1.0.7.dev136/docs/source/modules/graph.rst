API - 语义数据库管理 Neo4j 版本
========================

.. image:: my_figs/graph.ico
  :scale: 50 %

.. automodule:: chat.graph

.. autosummary::

   Database
   
语义数据库管理
------------------------
.. autofunction:: Database
